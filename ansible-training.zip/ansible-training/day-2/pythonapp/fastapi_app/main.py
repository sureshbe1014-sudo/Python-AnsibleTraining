from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def show_message():
    return {"messgae":"Welcome to Fast API"}

@app.get("/welcome")
def show_message():
    return {"messgae":"Welcome to Fast API 2.0"}