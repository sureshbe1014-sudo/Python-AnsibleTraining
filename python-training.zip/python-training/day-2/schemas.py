from sqlalchemy import Column,String
from .database import Base

class UserApp(Base):
    __tablename__ ="UserApp"

    uname=Column(String,primary_key=True)
    email=Column(String)
    password=Column(String)