from .database import engine
from . import schemas,crudmyapp
from fastapi import FastAPI

schemas.Base.metadata.create_all(engine)
app=FastAPI()

app.include_router(crudmyapp.router)
