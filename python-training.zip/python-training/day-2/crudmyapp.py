
from fastapi import FastAPI,APIRouter,status,HTTPException,Depends
from . import models,schemas
from .database import get_connection
from sqlalchemy.orm import Session

router = APIRouter(tags = ["User application"])

@router.post("/add-user")
def add_user(payload:models.User,db:Session=Depends(get_connection)):

    postData = schemas.UserApp(**payload.dict())
    db.add(postData)
    db.commit()

    return {"message": f"User details added - {postData}"}

@router.get("/load-users")
def load_users(db:Session=Depends(get_connection)):
    data = db.query(schemas.UserApp).all()
    return {"Users" : data}

@router.get("/load-user/{uname}")
def load_user(uname,db:Session=Depends(get_connection)):
    data = db.query(schemas.UserApp).filter(schemas.UserApp.uname == uname).first()
    if data == None:
        raise HTTPException(
            status_code = status.HTTP_404_NOT_FOUND, detail = "User Not Found"
        )
    return {"User" : data}

@router.delete("/delete-user/{uname}")
def delete_user(uname,db:Session=Depends(get_connection)):
    data = db.query(schemas.UserApp).filter(schemas.UserApp.uname == uname)
    if data.first() == None:
        raise(HTTPException(
            status_code = status.HTTP_404_NOT_FOUND, detail = "User Not Found"
        ))
    data.delete(synchronize_session=False)
    db.commit()
    return {"User" : data}

@router.put("/update-user/{uname}")
def update_user(uname,payload:models.User,db:Session=Depends(get_connection)):
    data = db.query(schemas.UserApp).filter(schemas.UserApp.uname == uname)
    if data.first() == None:
        raise(HTTPException(
            status_code = status.HTTP_404_NOT_FOUND, detail = "User Not Found"
        ))
    data.update(payload.dict(),synchronize_session=False)
    db.commit()
    return {"Updated User", data.first()}