class Sample:
    name = "Suresh"
    state = "TN"

    def __init__(self,email="user@gmail.com",city="Chennai"):
        self.email = email
        self.city = city

    def __str__(self):
        return f"{self.name} -{self.state}- {self.email} - {self.city}"

    def printSample(self):
        print(self.name,self.state,self.email,self.city)

s=Sample()
#s.printSample()
print(s)

s1 = Sample("admin@yahoo.com","Coimbatore")
s1.printSample()