from inheritance import RBI

class HEFC(RBI):
    def withdraw(amount):
        print("amount to be withdraw in HEFC")
    
    def openSalaryAccount(self):
        print("opened a salary account in HEFC")

    def checkBalance(self):
        print("Checking Balance in HEFC")

    def depositAmount(amount):
        print("Deposit amount in HEFC")

bank = HEFC()
bank.openSalaryAccount()
bank.withdraw()