from inheritance import RBI

class SBI(RBI):
    balance =1000
    def withdraw(self,amount):
        if self.balance < 500:
            print(f"balance in SBI is too low for  withdrawal")
            return False
        elif self.balance < amount:
            print(f"balance in SBI is lower than the speicified amount for withdrwal")
            return False
        else:
            print(f"amount to be withdraw in SBI - {amount}")
            self.balance -= amount
    
    def checkBalance(self):
        print(f" Balance in SBI - {self.balance}")

    def depositAmount(self,amount):
        
        print(f"Deposit amount {amount} in SBI")
        self.balance += amount
        
    def openSalaryAccount(self):
        print("opened a salary account in SBI")

bank = SBI()

bank.checkBalance()
bank.depositAmount(100)
bank.checkBalance()
bank.withdraw(300)
bank.checkBalance()
