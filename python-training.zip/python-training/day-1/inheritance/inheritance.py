
from abc import ABC,abstractmethod

class RBI(ABC):
    @abstractmethod
    def withdraw(amount):
        pass

    @abstractmethod
    def checkBalance():
        pass
    
    @abstractmethod
    def depositAmount(amount):
        pass

