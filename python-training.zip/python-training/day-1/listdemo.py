username = ['suresh','san',12,True]

for uname in username:
    print(uname)