print("welcome to python")

#this is variable declaration 
name = "Suresh"
age = 32
print(f"my name is {name} and my age is {age}")

a=12
if a > 10:
    print(f"{a} is greater than 10")
else:
    print(f"{a} is less than or equals to 10")