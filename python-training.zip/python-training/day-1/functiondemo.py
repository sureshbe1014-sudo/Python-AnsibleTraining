def showwelcome():
    print("welcome")

def calculate(x,y):
    return x+y

showwelcome()
print(calculate(2,3))