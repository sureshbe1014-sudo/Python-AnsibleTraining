age = input("Enter your age : ")

if int(age) <= 0:
    print("Enter valid age")
elif int(age) < 18:
    print("Not allowed to vote")
elif int(age) >= 18 and int(age) <=79:
    print("allowed to vote")
else:
    print("senior citizen")
