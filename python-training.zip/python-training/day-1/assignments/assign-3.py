def showcalculation(arr):
    total =0 
    for num in arr:
        total += num
    return total

ar=[12,3,45,6.5]
result=showcalculation(ar)
print(result)