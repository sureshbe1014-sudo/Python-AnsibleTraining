use_number = []

data = int(input("Enter how many values to be added in List : "))

for i in range(data):
    val=int(input(f"enter value for Number {i}: "))
    use_number.append(val)

print(use_number)

for j in use_number:
    if(j%2==0):
        print(f"{j} is even")
    else:
        print(f"{j} is odd")
