name=input("Enter your name : ")
age=input("Enter your age : ")
print(f"User name : {name} and Age: {int(age)}")

a=input("Enter any value")
b=input("Enter any value")
c = int(a) + int(b)
print(f"Addition is : {c}")